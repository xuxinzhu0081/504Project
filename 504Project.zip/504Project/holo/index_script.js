$(document).ready(function(){
    $("raw_text").click(function(){
        $("#raw_text").hide();
    });
});
