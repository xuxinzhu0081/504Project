$(document).ready(function(){
     $("#raw_text").click(function(){
         $(this).hide();
     });
 });

//load raw text from query set by using button 
 

$